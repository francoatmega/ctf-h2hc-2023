#!/bin/sh

qemu-system-i386 \
    -m 32M \
    -drive format=raw,index=0,if=floppy,file=boot \
    -nographic \
    -snapshot  \
    -no-reboot \
    -monitor /dev/null 
