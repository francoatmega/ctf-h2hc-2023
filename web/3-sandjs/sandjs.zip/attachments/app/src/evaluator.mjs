import 'ses'
import os from 'os'

lockdown()

// endowments

const ALLOWED_PROCESS_ATTRIBUTES = [
    "env",
    "version",
    "argv",
    "arch",
    "kill",
    "cpuUsage"
]

const ALLOWED_OS_ATTRIBUTES = [
    "hostname",
    "type",
    "platform",
    "release",
    "uptime",
    "loadavg",
    "totalmem",
    "freemem",
    "cpus",
    "networkInterfaces"
]

function getInformationFromProcess(informations){
    if (!informations || !Array.isArray(informations) || informations.length === 0){
        throw new Error("No information specified")
    }
    if (Array.prototype.some.call(informations, information => {
        return !ALLOWED_PROCESS_ATTRIBUTES.includes(information) || typeof information !== "string"
    })){
        throw new Error("Not allowed attribute")
    }

    let ret = {}

    for (let i of informations){
        ret[i] = process[i]
    }

    return ret
}

function getInformationFromOs(info){
    if (!ALLOWED_OS_ATTRIBUTES.includes(info) || typeof info !== "string"){
        throw new Error("Not allowed attribute")
    }

    return os[info]();
}

// evaluate

export function evaluate(code){
    const endowments = {
        getInformationFromProcess,
        getInformationFromOs,
        console
    }

    const c = new Compartment(endowments)
    return c.evaluate(code)
}
