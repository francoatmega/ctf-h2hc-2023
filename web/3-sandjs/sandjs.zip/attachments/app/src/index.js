
const PORT = 3000;

const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.json({status: "200", message: "Welcome to the cluster script manager. Snippets can be posted to /evaluate"});
});

app.post("/evaluate", (req, res) => {
    const ret = evaluator.evaluate(req.body.code)
    res.json({status: "200", message: ret});
});

app.listen(PORT, async () => {
    evaluator = await import("./evaluator.mjs")
    console.log(`Example app listening at http://localhost:${PORT}`);
});
