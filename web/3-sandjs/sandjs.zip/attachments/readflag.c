// musl-gcc -o readflag -static readflag.c

#include <stdlib.h>
#include <stdio.h>

int main(void){
    char flag[100];

    // read flag
    FILE* f = fopen("/root/flag.txt", "r");
    fgets(flag, 100, f);

    // print flag
    printf("%s", flag);

    return 0;
}
