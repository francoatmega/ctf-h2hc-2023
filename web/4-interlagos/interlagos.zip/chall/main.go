package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"strings"
	"net/http"
	"os"
	"regexp"
	"path/filepath"
	"sync"
)

const baseDir = "notes"
var re_user = regexp.MustCompile("^[a-zA-Z0-9]*$")


type Note struct {
	ID    string `json:"id"`
	Title string `json:"title"`
	Body  string `json:"body"`
}

var mu = &sync.Mutex{}

func getNotePath(user, noteID string) string {
	return filepath.Join(baseDir, user, noteID+".json")
}


func containsAdmin(s string) bool {
	return strings.Contains(strings.ToLower(s), "admin")
}

func checkRequestForAdmin(r *http.Request) bool {
	// Check URI
	if containsAdmin(r.RequestURI) {
		return true
	}

	// Check headers
	for key, values := range r.Header {
		for _, value := range values {
			if containsAdmin(key) || containsAdmin(value) {
				return true
			}
		}
	}

	// Check body
	bodyBytes, err := ioutil.ReadAll(r.Body)
	if err != nil {
		// Handle error (perhaps return false or true depending on your use case)
		return false
	}
	// Ensure the body can be read again for subsequent handlers or middleware
	r.Body = ioutil.NopCloser(strings.NewReader(string(bodyBytes)))

	if containsAdmin(string(bodyBytes)) {
		return true
	}

	return false
}

func createNoteHandler(w http.ResponseWriter, r *http.Request) {
	var note Note
	err := json.NewDecoder(r.Body).Decode(&note)
	if err != nil {
		http.Error(w, "Failed to decode note", http.StatusBadRequest)
		return
	}

	user := r.Header.Get("User")
	// check regex for user only alphanumeric
	if user == "" || len(re_user.FindAllString(user,-1)) == 0 {
		http.Error(w, "No user header provided", http.StatusBadRequest)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	userDir := filepath.Join(baseDir, user)
	if _, err := os.Stat(userDir); os.IsNotExist(err) {
		os.MkdirAll(userDir, 0755)
	}


	notePath := getNotePath(user, note.ID)
	noteData, _ := json.Marshal(note)
	err = ioutil.WriteFile(notePath, noteData, 0644)
	if err != nil {
		http.Error(w, "Failed to save note", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusCreated)
}

func listNotesHandler(w http.ResponseWriter, r *http.Request) {
	user := r.Header.Get("User")
	if user == "" || len(re_user.FindAllString(user,-1)) == 0 {
		http.Error(w, "No user header provided", http.StatusBadRequest)
		return
	}

	if checkRequestForAdmin(r) {
		http.Error(w, "You can't list admin's notes", http.StatusBadRequest)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	var notes []Note
	userDir := filepath.Join(baseDir, user)
	files, _ := ioutil.ReadDir(userDir)
	for _, file := range files {
		noteData, err := ioutil.ReadFile(filepath.Join(userDir, file.Name()))
		if err != nil {
			continue
		}
		var note Note
		json.Unmarshal(noteData, &note)
		notes = append(notes, note)
	}

	json.NewEncoder(w).Encode(notes)
}

func getNoteHandler(w http.ResponseWriter, r *http.Request) {
	user := r.Header.Get("User")
	if user == "" || len(re_user.FindAllString(user,-1)) == 0 {
		http.Error(w, "No user header provided", http.StatusBadRequest)
		return
	}

		if checkRequestForAdmin(r) {
		http.Error(w, "You can't get admin's notes", http.StatusBadRequest)
		return
	}

	noteID := r.URL.Query().Get("id")
	if noteID == "" {
		http.Error(w, "No note ID provided", http.StatusBadRequest)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	notePath := getNotePath(user, noteID)
	noteData, err := ioutil.ReadFile(notePath)
	if err != nil {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	var note Note
	json.Unmarshal(noteData, &note)

	json.NewEncoder(w).Encode(note)
}

func editNoteHandler(w http.ResponseWriter, r *http.Request) {
	var updatedNote Note
	err := json.NewDecoder(r.Body).Decode(&updatedNote)
	if err != nil {
		http.Error(w, "Failed to decode note", http.StatusBadRequest)
		return
	}

	user := r.Header.Get("User")
	if user == "" || len(re_user.FindAllString(user,-1)) == 0{
		http.Error(w, "No user header provided", http.StatusBadRequest)
		return
	}

		if checkRequestForAdmin(r) {
		http.Error(w, "You can't edit admin's notes", http.StatusBadRequest)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	notePath := getNotePath(user, updatedNote.ID)
	_, err = os.Stat(notePath)
	if os.IsNotExist(err) {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	noteData, _ := json.Marshal(updatedNote)
	err = ioutil.WriteFile(notePath, noteData, 0644)
	if err != nil {
		http.Error(w, "Failed to update note", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func deleteNoteHandler(w http.ResponseWriter, r *http.Request) {
	user := r.Header.Get("User")
	if user == "" || len(re_user.FindAllString(user,-1)) == 0{
		http.Error(w, "No user header provided", http.StatusBadRequest)
		return
	}
		if checkRequestForAdmin(r) {
		http.Error(w, "You can't delete admin's notes", http.StatusBadRequest)
		return
	}

	noteID := r.URL.Query().Get("id")
	if noteID == "" {
		http.Error(w, "No note ID provided", http.StatusBadRequest)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	notePath := getNotePath(user, noteID)
	err := os.Remove(notePath)
	if err != nil {
		http.Error(w, "Failed to delete note", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}


func integrityCheckHandler(w http.ResponseWriter, r *http.Request) {
	tmpDir := "/tmp/notes"
	os.MkdirAll(tmpDir, 0755) // Ensure the tmp directory exists

	// 1. Copy all files to /tmp/notes directly without subdirs
	filepath.Walk(baseDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if !info.IsDir() {
			filename := filepath.Base(path) // Get the filename without any directories
			destPath := filepath.Join(tmpDir, filename)
			data, err := ioutil.ReadFile(path)
			if err != nil {
				return err
			}
			ioutil.WriteFile(destPath, data, 0644)
		}
		return nil
	})

	// 2. Read those notes from /tmp/notes
	var badFiles []string
	filepath.Walk(tmpDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		if !info.IsDir() {
			data, err := ioutil.ReadFile(path)
			if err != nil {
				return err
			}

			// 3. Check if they are well formed
			var note Note
			if err := json.Unmarshal(data, &note); err != nil || note.ID == "" || note.Title == "" {
				badFiles = append(badFiles, path)
			}
		}
		return nil
	})

	// 4. Deletes the tmp files
	os.RemoveAll(tmpDir)

	if len(badFiles) > 0 {
		w.WriteHeader(http.StatusBadRequest)
		w.Write([]byte("Found malformatted files: " + strings.Join(badFiles, ", ")))
		return
	}

	w.Write([]byte("All files are well-formed"))
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
		//read index.html
		index, err := ioutil.ReadFile("index.html")
		if err != nil {
			http.Error(w, "Failed to read index.html", http.StatusInternalServerError)
			return
		}
		// read main.go
		main, err := ioutil.ReadFile("main.go")
		if err != nil {
			http.Error(w, "Failed to read main.go", http.StatusInternalServerError)
			return
		}
		// concat index and main
		comment := []byte("<!--")
		index = append(index, comment...)
		index = append(index, main...)
		w.Write(index)
}


func main() {
	if _, err := os.Stat(baseDir); os.IsNotExist(err) {
		os.Mkdir(baseDir, 0755)
	}


	http.HandleFunc("/create", createNoteHandler)
	http.HandleFunc("/list", listNotesHandler)
	http.HandleFunc("/get", getNoteHandler)
	http.HandleFunc("/edit", editNoteHandler)
	http.HandleFunc("/delete", deleteNoteHandler)
	http.HandleFunc("/integrity", integrityCheckHandler)
	http.HandleFunc("/", indexHandler)

	fmt.Println("Server started on :8083")
	http.ListenAndServe(":8083", nil)
}

